const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  // Check if the provided credentials match any user
  const user = users.find((user) => user.username === username && user.password === password);

  if (user) {
    res.status(200).json({ message: 'Login successful' });
  } else {
    res.status(401).json({ message: 'Login failed' });
  }
});

app.get('/api/analytics', (req, res) => {
  // Sample data for analytics
  const analyticsData = [
    { name: 'Category A', value: 10 },
    { name: 'Category B', value: 20 },
    { name: 'Category C', value: 15 },
    { name: 'Category D', value: 30 },
    { name: 'Category E', value: 25 },
  ];

  res.json(analyticsData);
});

app.get('/api/data', (req, res) => {
  // Sample data for the data tab
  const rawData = [
    { id: 1, name: 'Category A', value: 10 },
    { id: 2, name: 'Category B', value: 20 },
    { id: 3, name: 'Category C', value: 15 },
    { id: 4, name: 'Category D', value: 30 },
    { id: 5, name: 'Category E', value: 25 },
  ];

  res.json(rawData);
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});